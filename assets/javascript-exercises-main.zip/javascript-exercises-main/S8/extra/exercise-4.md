Añade un evento click al botón `Call a cat` que haga una petición a `https://api.thecatapi.com/v1/images/search`. Pinta la imagen que recibas de la api y añade además un botón `Eliminar` que elimine la imagen del gato.

Puedes hacer click tantas veces como quieras en el botón `Call a cat`. De modo que si hago click 5 veces, pintaré 5 gatos