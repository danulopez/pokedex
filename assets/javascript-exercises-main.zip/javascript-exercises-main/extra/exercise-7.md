Dado el siguiente string

```js
const text = `gracioso-pero-no-gracioso-de-risa-gracioso-de-raro`
```

transformalo en el siguiente (Mayusculas incluidas)

`Gracioso Pero No Gracioso De Risa Gracioso De Raro`