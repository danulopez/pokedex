const numbers = [32, 21, 63, 95, 100, 67, 43];

const foundNumber = numbers.find(number => number === 100);

console.log(foundNumber);