var carName = 'Volvo';
// let carName = 'Volvo';
// const carName = 'Volvo';

console.log(carName);