Elimina el último elemento del array y muestra el primero y el último por consola.
```js
const rickAndMortyCharacters = ["Rick", "Beth", "Jerry", "Morty", "Summer", "Lapiz Lopez"];
```