for (let index = 0; index < 10; index++) {
    if(index === 9){
        console.log('Dormido!')
    } else{
        console.log('Intentando dormir')
    }
}