const y = 10;
const z = 5;

const x = y + z;