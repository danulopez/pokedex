Basandote en el ejercicio anterior. Crea un botón que elimine el último elemento de la lista.
