const allCharacters$$ = document.body.querySelectorAll('[data-function="testMe"]');

console.log(allCharacters$$[2]);
// console.log(document.body.querySelectorAll('[data-function="testMe"]')[2]);