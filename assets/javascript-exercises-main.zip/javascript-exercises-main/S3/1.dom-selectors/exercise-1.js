const showMeButton$$ = document.querySelector('.showme');
console.log(showMeButton$$);