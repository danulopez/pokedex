const allPokemons$$ = document.body.querySelectorAll('.pokemon');

console.log(allPokemons$$);