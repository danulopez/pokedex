const div$$ = document.createElement('div');
const p$$ = document.createElement('p');

div$$.appendChild(p$$);

document.body.appendChild(div$$)